package ies.puerto.Interfaces;

public interface IVendible {
    public float precioMaximo();
    public int cantidadDisponible();

}
