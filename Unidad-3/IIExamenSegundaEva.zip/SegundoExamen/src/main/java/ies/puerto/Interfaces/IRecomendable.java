package ies.puerto.Interfaces;

public interface IRecomendable {

    public boolean productoRecomendado();
    public int calcularPopularidad();

}
